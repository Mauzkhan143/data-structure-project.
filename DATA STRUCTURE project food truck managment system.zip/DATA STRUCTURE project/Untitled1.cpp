#include <iostream>
#include <string.h>
#include <conio.h> 
using namespace::std;
static int count = 0;
class Deliverable{
	public:
		double weight_of_truck;
		int selection_of_food;
		string location;
		string date;
		string time;
		Deliverable* next;
	
		Deliverable(double weight, int selection, string loc, string date, string time){
		
			weight_of_truck = weight;
			selection_of_food = selection;
			location = loc;
			this->date = date;
			this->time = time;
			next = NULL;
		
		}
		void display(){
			cout<<endl<<"Truck weight (in KG): "<<weight_of_truck<<"\nYour Location = "<<location<<"\nDate and Time: "<<date<<" "<<time<<endl<<endl;
			if(selection_of_food == 1){
				cout<<"Your deliverable food will be Desi Food"<<endl;
			}
			else if(selection_of_food == 2){
				cout<<"Your deliverable food will be Fast Food"<<endl;
			}
			else if(selection_of_food == 3){
				cout<<"Your deliverable food will be Chinese Food"<<endl;
			}
		}	
	};


class Linkedlist{
	public:
	Deliverable* head;
	
		Linkedlist(){
			head = NULL;
		}
		
		void stack(Deliverable* currentDelivery){
			if(head == NULL){
				head = currentDelivery;
			}
			else{
				currentDelivery->next = head;
				head = currentDelivery;
			}
			
			cout<<"Great! Your Delivery is on the way."<<endl;
		}
		
		void traverseAllOrder(){
			if(head == NULL){
				cout<<"There is no order in pending"<<endl;
			}
			else{
			Deliverable* current = head;
			current->display();
			while(current->next != NULL){
				current = current->next;
				current->display();
			}
			}
		}
			
		void deliverOrder(){
			if(head == NULL){
				cout<<"There is no order in the stack"<<endl;
			}
			else{
				Deliverable* current = head;
				
				while(current->next != NULL){
				
					current = current->next;
				}
				
				delete current;
				cout<<"\nOrder Compeleted"<<endl;
		}
			
}

};
int main(int argc, char** argv) {
	
	Linkedlist* delivery = new Linkedlist();
	double weight_of_truck;
	int selection_of_food;
	string location;
	string date;
	string time;
	int ch;
	do{
		system("cls");
		cout<<"1. Ask customer to enter detail for new Order\n2. Deliver Order\n3. Traverse All Order\n4. Exit\n\nEnter Your Choice: ";
		cin>>ch;
		system("cls");
		
		if(ch == 1){
			cout<<"Welcome Dear Customer! Please Enter appropriate data\n";
			cout<<"Weight of truck(in kilogram): ";
			cin>>weight_of_truck;
			cout<<"Add place at which food will be delivered: ";
			cin>>location;
			cout<<"Enter Date of Delivery (DD/MM/YYYY) and hit space then enter time (HH:MM(am or pm)): ";
			cin>>date>>time;
			system("cls");
			cout<<"Select Food"<<endl;
			cout<<"1. Desi food \n2. Fast Food\n3. Chinese Food\nYour Choice: "<<endl;
			cin>>selection_of_food;
			
			delivery->stack(new Deliverable(weight_of_truck, selection_of_food, location, date, time));
			getch();	
		}
		else if(ch == 2){
			delivery->deliverOrder();
			getch();
		}
		else if(ch == 3){
			delivery->traverseAllOrder();
			getch();
		}
		
	}while(ch != 4);
		
	cout<<"Thank You"<<endl;
	
	return 0;
}
	
	
	
